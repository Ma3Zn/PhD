function gamma = leggi_gamma(dim)
%   Funzione che data la dimensione dello spazio in input restituiscela
%   gamma opportuna

load ./par/Gamma/Gamma_08apr.txt
gamma = Gamma_08apr*178.9817570338398;

end