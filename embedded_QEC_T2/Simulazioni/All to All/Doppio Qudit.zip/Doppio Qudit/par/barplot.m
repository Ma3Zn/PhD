figure(3)
clf
bar(zL_4)
hold on
bar(oL_4)
set(gca,'fontsize',32)
shg
xlim([0.5 12.5])
set(gcf,'position',[10,300,1000,200])
ylim([0 1])

figure(4)
clf
bar(zL_6)
hold on
bar(oL_6)
set(gca,'fontsize',32)
shg
xlim([0.5 12.5])
set(gcf,'position',[10,300,1000,200])
ylim([0 1])

figure(5)
clf
bar(zL_8)
hold on
bar(oL_8)
set(gca,'fontsize',32)
shg
xlim([0.5 12.5])
set(gcf,'position',[10,300,1000,200])
ylim([0 1])

figure(6)
clf
bar(zL_10)
hold on
bar(oL_10)
set(gca,'fontsize',32)
shg
xlim([0.5 12.5])
set(gcf,'position',[10,300,1000,200])
ylim([0 1])

figure(8)
clf
bar(zL_12)
hold on
bar(oL_12)
set(gca,'fontsize',32)
shg
set(gcf,'position',[10,300,1000,200])
xlim([0.5 12.5])
ylim([0 1])